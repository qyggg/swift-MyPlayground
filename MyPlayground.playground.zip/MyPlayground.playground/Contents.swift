//: Playground - noun: a place where people can play

import UIKit

//1,基本类型之常量,变量和声明
// 变量用 var声明,常量用let声明
//swift语言是强类型语言,每一个变量都有一个固定的类型(当给一个变量赋上一个初值时,该变量的类型就确定了(type inference 机制))
//按住option键,鼠标放在变量上即可查看变量类型
var str = "Hello, playground"
//str = 1
str = "hello"

let maxNum = 1000


//一个语句中可以同时声明多个变量
var x = 1, y=2, z=3


let website: String = "www.imooc.com"


//同时声明多个变量并声明类型
var a, b ,c:Double

//-------------------------------------------2,基本类型之整型------------------------------------------------------
//常用类型: int float double  boolean  string tuple
var imInt: Int = 80
Int.max
Int.min
//imInt=9999999999999999999999

//无符号整型
var  imUInt:UInt = 80
UInt.max

//UInt无法存储负数
UInt.min


//Int8
Int8.max
Int8.min

UInt8.max
UInt8.min

Int16.max
Int16.min

UInt16.max
UInt16.min

Int32.max
Int32.min

UInt32.max
UInt32.min

Int64.max
Int64.min

UInt64.max
UInt64.min

let d = 4

let decimalInt: Int = 17

//二进制赋值
let binaryInt:  Int = 0b10001

//8进制 16进制赋值
let octalInt: Int = 0o21
let hexInt: Int = 0x11


//位数多时可用下划线分割,下划线不作计数
let bignum = 100_0000


//--------------------------------------------------2-3,基本类型之浮点数和类型转换-------------------------

//float类型后两位存不住  3.14159
let imFloat: Float = 3.1415926


//double类型可存到后两位  3.1415926
let imDouble: Double = 3.1415926


//变量不指定类别时,系统可自动判断为double类型
let n = 3.1415926

//科学计数法  12500000000
var m = 1.25e10

var k = 1.25e-8

var s = 1_000_000.000_000_1


//不同类型相加
let q: UInt16 = 100

let w: UInt8 = 20

let e = w+UInt8(q)
let r = UInt16(w)+q

let t: Double = 3.0
let u: Float = 0.3
t+Double (u)
Float (t)+u

let i:Float = 3
let o:Int  = 3
let g:Int = Int(3.2)


let integer = 3
let fraction = 0.1415926
let pi = Double (integer)+fraction


//CGFloat 用于界面开发的数据
let red:CGFloat = 0.2
let green:CGFloat = 0.5
let blue:CGFloat = 0.3

UIColor(red: red, green: green, blue: blue, alpha: 1)

//------------------------2.4,基本类型之布尔类型和简单的if语句----------------------------


let imTrue:Bool = true
let imFlase = false

if imFlase
{
    print("I am True")
}
    else if  3+4==7
{
    print("3+4==7")
}

//else
//{
//    print("i am False")
//}

//int 不能解读为布尔类型 eg: if 1{}  ❌  但是 if a==2 {}✅

//-------------------- 2.5基本类型之元组---------------------
//元组:将多个数据类型放在一个数组中


//元组的赋值在小括号中写入各个数据,数据之间用逗号隔开,元组中不仅仅可以存储同一数据类型,也可以存储不同的数据类型
//元组特点:可以有任意多个值,不同的值可以是不同的数据类型
var point = (5,2)
var httpResponse = (404,"Not found")

var point2:(Int,Int,Int) = (10,5,2)
var httpResponse2:(Int,String) = (200,"OK")

let (f , h) = point
f
h

var (stateCode,stateMessage) = httpResponse
stateCode
stateMessage

stateCode = 405
point.0
point.1

let point3 = (d:3,l:2)
point3.d
point3.l

let point4:(x:Int ,y:Int)=(10,5)
point4.x
point4.y


//使用下划线忽略一些值
let loginResult = (true,"liuyongbobo")
let (isLoginSuccess,_) = loginResult

if isLoginSuccess
{
    print("login Success!")
}
else
{
    print("login Failed!")
}

//------------------------------2.6基本类型之其他:变量名,print和注释-----------------------
//string 使用双引号 eg:
// 类型的名称首字母大写
//变量的名称可以是任意类型
let website2: String = "www.imooc.com"

var 名字 = "liuyubobobo"
print("我的名字是"+名字)

var 😀 = "smile"
print(名字+😀)

print("hello")

//separator 空格  terminator回车
let x1=1,y1=2,z1=3
print(x1,y1,z1)
print(x1,y1,z1,separator:"----")
print(x1,y1,z1,separator:"----",terminator:":)")
print("hello")
print(y1,"*",z1,"=",y1*z1)

//  \(y1)  斜杠+变量表示变量的值
//swift中多行注释仍能插入多行注释

/*
 私发私发啊
  /*
 大发发发
 */
 */
print("\(y1)*\(z1)=\(y1*z1)")




























